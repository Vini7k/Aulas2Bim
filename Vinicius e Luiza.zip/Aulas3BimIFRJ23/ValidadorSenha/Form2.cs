﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ValidadorSenha
{
    public partial class Frm_Mascara : Form
    {
        public Frm_Mascara()
        {
            InitializeComponent();
        }
        private void Frm_Mascara_Load(object sender, EventArgs e)
        {

        }
        private void Bnt_Senha_Click(object sender, EventArgs e)
        {
            Msk_TextBox.UseSystemPasswordChar = true;
            Lbl_Conteudo.Text = "";
            Msk_TextBox.Mask = "";
            Lbl_MascaraAtiva.Text = Msk_TextBox.Mask;
            Msk_TextBox.Text = "";
            Msk_TextBox.Focus();
        }
        private void Bnt_Hora_Click(object sender, EventArgs e)
        {
            Msk_TextBox.UseSystemPasswordChar = true;
            Lbl_Conteudo.Text = "";
            Msk_TextBox.Mask = "00:00";
            Lbl_MascaraAtiva.Text = Msk_TextBox.Mask;
            Msk_TextBox.Text = "";
            Msk_TextBox.Focus();
        }  
        private void Bnt_CEP_Click(object sender, EventArgs e)
        {
            Msk_TextBox.UseSystemPasswordChar = true;
            Lbl_Conteudo.Text = "";
            Msk_TextBox.Mask = "00000-000";
            Lbl_MascaraAtiva.Text = Msk_TextBox.Mask;
            Msk_TextBox.Text = "";
            Msk_TextBox.Focus();
        }
        private void Bnt_Moeda_Click(object sender, EventArgs e)
        {
            Msk_TextBox.UseSystemPasswordChar = true;
            Lbl_Conteudo.Text = "";
            Msk_TextBox.Mask = "$ 000,000,000.00";
            Lbl_MascaraAtiva.Text = Msk_TextBox.Mask;
            Msk_TextBox.Text = "";
            Msk_TextBox.Focus();
        }
        private void Bnt_Data_Click(object sender, EventArgs e)
        {
            Msk_TextBox.UseSystemPasswordChar = true;
            Lbl_Conteudo.Text = "";
            Msk_TextBox.Mask = "00/00/0000";
            Lbl_MascaraAtiva.Text = Msk_TextBox.Mask;
            Msk_TextBox.Text = "";
            Msk_TextBox.Focus();
        }
        private void Bnt_Telefone_Click(object sender, EventArgs e)
        {
            Msk_TextBox.UseSystemPasswordChar = true;
            Lbl_Conteudo.Text = "";
            Msk_TextBox.Mask = "(00)0000-0000";
            Lbl_MascaraAtiva.Text = Msk_TextBox.Mask;
            Msk_TextBox.Text = "";
            Msk_TextBox.Focus();
        }
        private void Bnt_VerConteudo_Click(object sender, EventArgs e)
        {
            Lbl_Conteudo.Text = Msk_TextBox.Text;
            if (Msk_TextBox.Mask == "00:00")
            {
                bool ValidaTudo = false;
                Uteis valida = new Uteis();
                ValidaTudo = valida.ValidaHora(Msk_TextBox.Text);
                if (ValidaTudo == true)
                {
                    Lbl_Validacao.Text = "VÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Green;
                }
                else
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;
                }

            }

            if (Msk_TextBox.Mask == "")
            {
                int ValidaTudo;
                Uteis valida = new Uteis();
                ValidaTudo = valida.ValidaSenha(Msk_TextBox.Text);
                
                if(ValidaTudo == 0)
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;
                    MessageBox.Show("A senha deve conter no mínimo 8 caracteres");
                    
                }
                if (ValidaTudo == 1)
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;
                    MessageBox.Show("A senha deve conter no máximo 16 caracteres");
                }
                if (ValidaTudo == 2)
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;
                    MessageBox.Show("A senha não possui letra maiuscula");
                }
                if (ValidaTudo == 3)
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;
                    MessageBox.Show("A senha não possui letra minuscula");
                }
                if (ValidaTudo == 4)
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;
                    MessageBox.Show("A senha não possui caracter especial");
                }
                if (ValidaTudo == 5)
                {
                    Lbl_Validacao.Text = "VÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Green;
                }
            }

            if (Msk_TextBox.Mask == "00/00/0000")
            {
                bool ValidaTudo = false;
                Uteis valida = new Uteis();
                ValidaTudo = valida.ValidaData(Msk_TextBox.Text);
                if (ValidaTudo == true)
                {
                    Lbl_Validacao.Text = "VÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Green;

                }
                else
                {
                    Lbl_Validacao.Text = "INVÁLIDO";
                    Lbl_Validacao.ForeColor = Color.Red;

                }
            }
        }
    }
}
