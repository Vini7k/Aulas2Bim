﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorSenha
{
    public class Uteis
    {
        public int ValidaSenha(string senha)
        {
            if (senha.Length < 8)
            {
                return 0;
            }
            if (senha.Length > 16)
            {
                return 1;
            }

            bool temLetraMaiuscula = senha.Any(char.IsUpper);
            bool temLetraMinuscula = senha.Any(char.IsLower);
            bool temCaracterEspecial = senha.Any(c => !char.IsLetterOrDigit(c));

            if (temLetraMaiuscula == true)
            {
                if (temLetraMinuscula == true)
                {
                    if (temCaracterEspecial == true)
                    {
                        return 5;
                    }                   
                    return 4 ;
                }
                return 3 ;
            }
            return 2;
        }

        public bool ValidaHora (string horario)
        {
            if (horario.Length != 5)
            {
                return false;
            }

            string horasParte = horario.Substring(0, 2);
            string minutosParte = horario.Substring(3, 2);

            if (!int.TryParse(horasParte, out int horas) || !int.TryParse(minutosParte, out int minutos))
            {
                return false;
            }

            if (horas < 0 || horas > 23 || minutos < 0 || minutos > 59)
            {
                return false;
            }

            return horario[2] == ':';

        }
        public bool ValidaData (string data)
        {
            if (data.Length != 10)
            {
                return false;
            }

            string diaParte = data.Substring(0, 2);
            string mesParte = data.Substring(3, 2);
            string anoParte = data.Substring(6, 4);

            if (!int.TryParse(diaParte, out int dias) || !int.TryParse(mesParte, out int mes) || !int.TryParse(anoParte, out int ano))
            {
                return false;
            }

            if (dias < 0 || dias > 31 || mes < 0 || mes > 12 || ano < 0)
            {
                return false;
            }

            return data[2] == '/' && data[5] == '/';
        }
    }
}
