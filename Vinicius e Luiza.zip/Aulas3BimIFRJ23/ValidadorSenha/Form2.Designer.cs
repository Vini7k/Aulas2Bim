﻿namespace ValidadorSenha
{
    partial class Frm_Mascara
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Msk_TextBox = new System.Windows.Forms.MaskedTextBox();
            this.Lbl_Conteudo = new System.Windows.Forms.Label();
            this.Lbl_MascaraAtiva = new System.Windows.Forms.Label();
            this.Bnt_Hora = new System.Windows.Forms.Button();
            this.Bnt_CEP = new System.Windows.Forms.Button();
            this.Bnt_Moeda = new System.Windows.Forms.Button();
            this.Bnt_Data = new System.Windows.Forms.Button();
            this.Bnt_Senha = new System.Windows.Forms.Button();
            this.Bnt_Telefone = new System.Windows.Forms.Button();
            this.Bnt_VerConteudo = new System.Windows.Forms.Button();
            this.Lbl_Validacao = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Msk_TextBox
            // 
            this.Msk_TextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Msk_TextBox.Location = new System.Drawing.Point(23, 31);
            this.Msk_TextBox.Name = "Msk_TextBox";
            this.Msk_TextBox.Size = new System.Drawing.Size(258, 26);
            this.Msk_TextBox.TabIndex = 0;
            // 
            // Lbl_Conteudo
            // 
            this.Lbl_Conteudo.AutoSize = true;
            this.Lbl_Conteudo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbl_Conteudo.Location = new System.Drawing.Point(23, 246);
            this.Lbl_Conteudo.Name = "Lbl_Conteudo";
            this.Lbl_Conteudo.Size = new System.Drawing.Size(0, 19);
            this.Lbl_Conteudo.TabIndex = 1;
            // 
            // Lbl_MascaraAtiva
            // 
            this.Lbl_MascaraAtiva.AutoSize = true;
            this.Lbl_MascaraAtiva.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbl_MascaraAtiva.Location = new System.Drawing.Point(23, 75);
            this.Lbl_MascaraAtiva.Name = "Lbl_MascaraAtiva";
            this.Lbl_MascaraAtiva.Size = new System.Drawing.Size(0, 19);
            this.Lbl_MascaraAtiva.TabIndex = 2;
            // 
            // Bnt_Hora
            // 
            this.Bnt_Hora.Location = new System.Drawing.Point(23, 110);
            this.Bnt_Hora.Name = "Bnt_Hora";
            this.Bnt_Hora.Size = new System.Drawing.Size(82, 37);
            this.Bnt_Hora.TabIndex = 3;
            this.Bnt_Hora.Text = "Hora";
            this.Bnt_Hora.UseVisualStyleBackColor = true;
            this.Bnt_Hora.Click += new System.EventHandler(this.Bnt_Hora_Click);
            // 
            // Bnt_CEP
            // 
            this.Bnt_CEP.Location = new System.Drawing.Point(111, 110);
            this.Bnt_CEP.Name = "Bnt_CEP";
            this.Bnt_CEP.Size = new System.Drawing.Size(82, 37);
            this.Bnt_CEP.TabIndex = 4;
            this.Bnt_CEP.Text = "CEP";
            this.Bnt_CEP.UseVisualStyleBackColor = true;
            this.Bnt_CEP.Click += new System.EventHandler(this.Bnt_CEP_Click);
            // 
            // Bnt_Moeda
            // 
            this.Bnt_Moeda.Location = new System.Drawing.Point(199, 110);
            this.Bnt_Moeda.Name = "Bnt_Moeda";
            this.Bnt_Moeda.Size = new System.Drawing.Size(82, 37);
            this.Bnt_Moeda.TabIndex = 5;
            this.Bnt_Moeda.Text = "Moeda";
            this.Bnt_Moeda.UseVisualStyleBackColor = true;
            this.Bnt_Moeda.Click += new System.EventHandler(this.Bnt_Moeda_Click);
            // 
            // Bnt_Data
            // 
            this.Bnt_Data.Location = new System.Drawing.Point(23, 153);
            this.Bnt_Data.Name = "Bnt_Data";
            this.Bnt_Data.Size = new System.Drawing.Size(82, 37);
            this.Bnt_Data.TabIndex = 6;
            this.Bnt_Data.Text = "Data";
            this.Bnt_Data.UseVisualStyleBackColor = true;
            this.Bnt_Data.Click += new System.EventHandler(this.Bnt_Data_Click);
            // 
            // Bnt_Senha
            // 
            this.Bnt_Senha.Location = new System.Drawing.Point(111, 153);
            this.Bnt_Senha.Name = "Bnt_Senha";
            this.Bnt_Senha.Size = new System.Drawing.Size(82, 37);
            this.Bnt_Senha.TabIndex = 7;
            this.Bnt_Senha.Text = "Senha";
            this.Bnt_Senha.UseVisualStyleBackColor = true;
            this.Bnt_Senha.Click += new System.EventHandler(this.Bnt_Senha_Click);
            // 
            // Bnt_Telefone
            // 
            this.Bnt_Telefone.Location = new System.Drawing.Point(199, 153);
            this.Bnt_Telefone.Name = "Bnt_Telefone";
            this.Bnt_Telefone.Size = new System.Drawing.Size(82, 37);
            this.Bnt_Telefone.TabIndex = 8;
            this.Bnt_Telefone.Text = "Telefone";
            this.Bnt_Telefone.UseVisualStyleBackColor = true;
            this.Bnt_Telefone.Click += new System.EventHandler(this.Bnt_Telefone_Click);
            // 
            // Bnt_VerConteudo
            // 
            this.Bnt_VerConteudo.Location = new System.Drawing.Point(23, 196);
            this.Bnt_VerConteudo.Name = "Bnt_VerConteudo";
            this.Bnt_VerConteudo.Size = new System.Drawing.Size(258, 37);
            this.Bnt_VerConteudo.TabIndex = 9;
            this.Bnt_VerConteudo.Text = "Ver Conteúdo";
            this.Bnt_VerConteudo.UseVisualStyleBackColor = true;
            this.Bnt_VerConteudo.Click += new System.EventHandler(this.Bnt_VerConteudo_Click);
            // 
            // Lbl_Validacao
            // 
            this.Lbl_Validacao.AutoSize = true;
            this.Lbl_Validacao.Location = new System.Drawing.Point(228, 78);
            this.Lbl_Validacao.Name = "Lbl_Validacao";
            this.Lbl_Validacao.Size = new System.Drawing.Size(0, 15);
            this.Lbl_Validacao.TabIndex = 11;
            // 
            // Frm_Mascara
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(312, 284);
            this.Controls.Add(this.Lbl_Validacao);
            this.Controls.Add(this.Bnt_VerConteudo);
            this.Controls.Add(this.Bnt_Telefone);
            this.Controls.Add(this.Bnt_Senha);
            this.Controls.Add(this.Bnt_Data);
            this.Controls.Add(this.Bnt_Moeda);
            this.Controls.Add(this.Bnt_CEP);
            this.Controls.Add(this.Bnt_Hora);
            this.Controls.Add(this.Lbl_MascaraAtiva);
            this.Controls.Add(this.Lbl_Conteudo);
            this.Controls.Add(this.Msk_TextBox);
            this.Name = "Frm_Mascara";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemplos de Máscaras";
            this.Load += new System.EventHandler(this.Frm_Mascara_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MaskedTextBox Msk_TextBox;
        private Label Lbl_Conteudo;
        private Label Lbl_MascaraAtiva;
        private Button Bnt_Hora;
        private Button Bnt_CEP;
        private Button Bnt_Moeda;
        private Button Bnt_Data;
        private Button Bnt_Senha;
        private Button Bnt_Telefone;
        private Button Bnt_VerConteudo;
        private Label Lbl_Validacao;
    }
}