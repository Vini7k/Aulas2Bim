﻿namespace ValidadorSenha
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Txt_Senha = new System.Windows.Forms.TextBox();
            this.Lbl_Resultado = new System.Windows.Forms.Label();
            this.Bnt_Reset = new System.Windows.Forms.Button();
            this.bnt_Valida = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Txt_Senha
            // 
            this.Txt_Senha.Location = new System.Drawing.Point(12, 45);
            this.Txt_Senha.Name = "Txt_Senha";
            this.Txt_Senha.PasswordChar = '*';
            this.Txt_Senha.Size = new System.Drawing.Size(218, 23);
            this.Txt_Senha.TabIndex = 0;
            this.Txt_Senha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Txt_Senha_KeyDown);
            // 
            // Lbl_Resultado
            // 
            this.Lbl_Resultado.AutoSize = true;
            this.Lbl_Resultado.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Lbl_Resultado.Location = new System.Drawing.Point(12, 90);
            this.Lbl_Resultado.Name = "Lbl_Resultado";
            this.Lbl_Resultado.Size = new System.Drawing.Size(0, 22);
            this.Lbl_Resultado.TabIndex = 1;
            // 
            // Bnt_Reset
            // 
            this.Bnt_Reset.Location = new System.Drawing.Point(245, 42);
            this.Bnt_Reset.Name = "Bnt_Reset";
            this.Bnt_Reset.Size = new System.Drawing.Size(111, 23);
            this.Bnt_Reset.TabIndex = 2;
            this.Bnt_Reset.Text = "Limpa";
            this.Bnt_Reset.UseVisualStyleBackColor = true;
            this.Bnt_Reset.Click += new System.EventHandler(this.Bnt_Reset_Click);
            // 
            // bnt_Valida
            // 
            this.bnt_Valida.Location = new System.Drawing.Point(245, 71);
            this.bnt_Valida.Name = "bnt_Valida";
            this.bnt_Valida.Size = new System.Drawing.Size(111, 23);
            this.bnt_Valida.TabIndex = 3;
            this.bnt_Valida.Text = "Ver Senha";
            this.bnt_Valida.UseVisualStyleBackColor = true;
            this.bnt_Valida.Click += new System.EventHandler(this.bnt_Valida_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 154);
            this.Controls.Add(this.bnt_Valida);
            this.Controls.Add(this.Bnt_Reset);
            this.Controls.Add(this.Lbl_Resultado);
            this.Controls.Add(this.Txt_Senha);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validador de Senhas";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Txt_Senha;
        private Label Lbl_Resultado;
        private Button Bnt_Reset;
        private Button bnt_Valida;
    }
}